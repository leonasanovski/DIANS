import os
import pandas as pd
import matplotlib.pyplot as plt
from flask import Flask, render_template, redirect, url_for, request, flash, session, send_file
from io import BytesIO
import base64
import time

app = Flask(__name__)
app.secret_key = 'your_secret_key'


def load_companies_from_csv():
    file_path = 'results.csv'
    if os.path.exists(file_path):
        df = pd.read_csv(file_path)
        companies = df['Компанија'].unique()
        return companies
    return []


@app.route('/')
def home():
    if 'user' in session:
        companies = load_companies_from_csv()
        return render_template('home.html', companies=companies)
    return redirect(url_for('login'))


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        session['user'] = username
        return redirect(url_for('home'))
    return render_template('login.html')


@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        session['user'] = username
        flash('Account created successfully!')
        return redirect(url_for('home'))
    return render_template('signup.html')


@app.route('/company_data', methods=['POST'])
def company_data():
    company = request.form['company']
    df = pd.read_csv('results.csv')
    company_data = df[df['Компанија'] == company]
    company_data['Цена на последна трансакцја'] = company_data['Цена на последна трансакција']
    processed_prices = []
    for price in company_data['Цена на последна трансакција']:
        price_part = price.split(',')[0]
        price_part = price_part.replace('.', '')
        processed_prices.append(price_part)
    company_data['Цена на последна трансакција'] = pd.to_numeric(processed_prices, errors='coerce')
    company_data['Датум'] = pd.to_datetime(company_data['Датум'], format='%m/%d/%Y')

    company_data['Year'] = company_data['Датум'].dt.year

    company_data_grouped = company_data.groupby('Year')['Цена на последна трансакција'].mean()
    plt.figure(figsize=(10, 6))
    company_data_grouped.plot(kind='line', legend=False)
    plt.title(f"Price History for {company}")
    plt.xlabel('Year')
    plt.ylabel('Average Price')
    img_stream = BytesIO()
    plt.savefig(img_stream, format='png')
    plt.close()
    img_stream.seek(0)

    img_base64 = base64.b64encode(img_stream.getvalue()).decode('utf-8')
    columns = [
        "Датум",
        "Цена на последна трансакцја",
        "Мак.",
        "Мин.",
        "Просечна цена",
        "%пром.",
        "Количина",
        "Промет во БЕСТ во денари",
        "Вкупен промет во денари",
        "Компанија",
        "Year"
    ]

    return render_template('company_data.html', company=company,
                           data=company_data[columns].to_html(classes='table table-striped'), chart=img_base64)


@app.route('/logout')
def logout():
    session.pop('user', None)
    return redirect(url_for('login'))


@app.route('/update_database', methods=['POST'])
def update_database():
    return render_template('loading.html', time_left=180)


@app.route('/start_update')
def start_update():
    time.sleep(180)
    return redirect(url_for('home'))


if __name__ == '__main__':
    app.run(debug=True)
